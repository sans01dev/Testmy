# 정리각 (jungni) — web-framework 버전

토스 WebView 미니앱. 연락처는 `@apps-in-toss/web-framework`의 **`fetchContacts`를 직접 호출**해서 읽습니다.
(RN+웹뷰 하이브리드 아님 — 네 평소 단일파일 스타일에 가까운 web 경로)

## 구조
```
public/index.html   정리각 마크업 + CSS (webpack이 bundle.js 주입)
src/main.ts         앱 로직 전체 + fetchContacts 연동 (여기만 고치면 됨)
granite.config.ts   appName=jungni, 연락처 read 권한, 브랜드(#2E7D8A)
webpack.config.js   entry=src/main.ts, html-webpack-plugin
package.json        dev: granite dev / build: granite build / deploy: ait deploy
```

## 로컬 실행 (PC + 폰 같은 와이파이)
```bash
yarn install
yarn dev        # webpack dev server + 샌드박스 연결
```
- 실기기 테스트: `granite.config.ts`의 `web.host`를 폰에서 접근되는 IP(예: 192.168.0.x)로 바꾸고
  샌드박스 앱에서 `intoss://jungni` 스킴 열기.
- ⚠️ 로컬 브라우저에서는 SDK/TDS가 안 돌아 테스트 불가 → **샌드박스 앱**으로 테스트.
  (로컬 브라우저로 열면 연락처는 MOCK 데이터로만 보임.)

## 연락처 동작 (검증됨)
```ts
import { fetchContacts, FetchContactsPermissionError } from '@apps-in-toss/web-framework';
// fetchContacts({ size, offset }) → { result:[{name, phoneNumber}], nextOffset, done }
// fetchContacts.getPermission() / fetchContacts.openPermissionDialog()
```
- 권한: `granite.config.ts`의 `permissions:[{name:'contacts',access:'read'}]`
- 이 프로젝트는 실제 `npx webpack` 빌드로 컴파일 성공 확인함.

## 빌드 & 콘솔 배포 (SDK 2.x — 실측 검증됨)
```bash
npm install
npx ait build     # jungni.ait 생성 (RN 0.84 + 0.72 동시 빌드)
npx ait deploy --api-key <콘솔 API 키>
```
- `@apps-in-toss/web-framework@2.10.4` 사용 (fetchContacts 포함 확인).
- clean install → `ait build` → `jungni.ait` 생성까지 실제로 돌려서 검증함.

## 폰만으로 배포 (GitHub Actions)
`.github/workflows/deploy.yml` 포함. push하면 러너가 `ait build`→`ait deploy` 실행.
사전 1회: 콘솔에 `jungni` 앱 등록 + API 키 발급 → repo Secret `AIT_API_KEY` 저장.

## 백업(VCF)
navigator.share(파일) → 안 되면 blob 다운로드 → 최후 텍스트 복사.
토스 SDK의 공유 함수로 바꾸고 싶으면 main.ts의 `shareVCF`만 교체하면 됨.
