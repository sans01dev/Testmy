import { defineConfig } from '@apps-in-toss/web-framework/config';

export default defineConfig({
  appName: 'jungni', // 앱인토스 콘솔의 앱 이름과 동일해야 함
  web: {
    // 실기기(샌드박스) 테스트 시: host를 폰에서 접근 가능한 IP로 바꾸고 --host 사용
    // 예) host: '192.168.0.100'
    host: 'localhost',
    port: 8080,
    commands: {
      dev: 'webpack serve --mode development',
      build: 'webpack',
    },
  },
  // 연락처 읽기 권한 (fetchContacts 사용에 필요)
  permissions: [
    { name: 'contacts', access: 'read' },
  ],
  outdir: 'dist',
  brand: {
    displayName: '정리각',
    // TODO: 정리각 아이콘 URL로 교체
    icon: 'https://static.toss.im/appsintoss/73/ce76ba9b-c384-49b8-8bb9-2017f903f455.png',
    primaryColor: '#2E7D8A',
    bridgeColorMode: 'basic',
  },
});
