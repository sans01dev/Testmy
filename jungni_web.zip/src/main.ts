// 정리각 v0.3 (web-framework) — 연락처는 @apps-in-toss/web-framework의 fetchContacts 직접 호출
import { fetchContacts, FetchContactsPermissionError } from '@apps-in-toss/web-framework';

/* ================= 설정/상태 ================= */
var contacts = [];       // 전체 연락처 [{name, phoneNumber}]
var deckList = [];       // 현재 덱(정리 후보)
var deckIdx = 0;
var mode = 'noname';     // 'noname' | 'dup'
var noNameList = [];
var dupList = [];
var checkedCount = 0;

/* ================= 화면 전환 ================= */
function show(id){
  var scs = document.querySelectorAll('.screen');
  for(var i=0;i<scs.length;i++) scs[i].classList.remove('on');
  document.getElementById('s-'+id).classList.add('on');
  window.scrollTo(0,0);
}

/* ================= 토스트 ================= */
var _toastT;
function toast(msg){
  var t=document.getElementById('toast');
  t.textContent=msg; t.classList.add('show');
  clearTimeout(_toastT);
  _toastT=setTimeout(function(){ t.classList.remove('show'); }, 1900);
}

/* ================= 전화번호 정규화 ================= */
function normPhone(p){
  return (p||'').replace(/[^0-9+]/g,'');
}
function fmtPhone(p){
  var n=normPhone(p);
  // 한국 휴대폰 010-XXXX-XXXX 포맷
  if(/^01[016789]\d{7,8}$/.test(n)){
    if(n.length===11) return n.replace(/(\d{3})(\d{4})(\d{4})/,'$1-$2-$3');
    if(n.length===10) return n.replace(/(\d{3})(\d{3})(\d{4})/,'$1-$2-$3');
  }
  return p||n;
}

/* ================= 연락처 불러오기 =================
   토스 WebView: @apps-in-toss/web-framework의 fetchContacts.
   HTML 단독(미리보기/PC)에선 SDK 없음 → MOCK로 UI 확인.
   실제 앱에선 아래 fetchAllContacts가 SDK를 통해 동작. */
var MOCK = [
  {name:'', phoneNumber:'010-1234-5678'},
  {name:'', phoneNumber:'010-2222-3333'},
  {name:'김철수', phoneNumber:'010-5555-6666'},
  {name:'', phoneNumber:'02-681-3738'},
  {name:'엄마', phoneNumber:'010-9999-0000'},
  {name:'김철수', phoneNumber:'010-5555-6666'},   // 중복
  {name:'', phoneNumber:'031-777-8888'},
  {name:'박영희', phoneNumber:'010-1111-2222'},
  {name:'박영희', phoneNumber:'010-1111-2222'},   // 중복
];

/* ================= 연락처 불러오기 (web-framework SDK) =================
   토스 WebView: @apps-in-toss/web-framework 의 fetchContacts 를 직접 호출.
   로컬 브라우저엔 SDK가 없어 MOCK으로 UI만 확인 (실기기 테스트는 샌드박스앱). */
// 권한이 명확히 허용 상태가 아니면 권한 다이얼로그를 띄움.
// (getPermission 반환값 형태에 의존하지 않도록, 실제 판별은 fetchContacts 호출이 담당)
async function ensureContactsPermission(){
  try{
    var status = await fetchContacts.getPermission();
    var granted = (status === 'granted' || status === 'authorized' || status === true);
    if(!granted){ await fetchContacts.openPermissionDialog(); }
  }catch(e){ /* getPermission 미지원/실패는 무시하고 아래 fetch에서 판별 */ }
}

// 전체 연락처를 페이지네이션으로 다 가져옴
async function fetchAllContacts(){
  try{
    await ensureContactsPermission();
    var all = [], offset = 0, guard = 0;
    while(guard < 500){
      guard++;
      var res = await fetchContacts({ size:50, offset:offset });
      if(!res || !res.result) break;
      all = all.concat(res.result);
      if(res.done || res.nextOffset == null) break;
      offset = res.nextOffset;
    }
    return all;
  }catch(e){
    // 권한 거부 → 상위(startScan)에서 안내/재요청
    if(e instanceof FetchContactsPermissionError){ throw new Error('PERMISSION_DENIED'); }
    // SDK 미동작(로컬 브라우저 등) → MOCK 으로 UI 확인
    await new Promise(function(r){ setTimeout(r, 500); });
    return MOCK.slice();
  }
}

/* ================= 분류 ================= */
function classify(list){
  noNameList = [];
  dupList = [];
  // 이름 없음
  for(var i=0;i<list.length;i++){
    var c=list[i];
    var nm=(c.name||'').trim();
    if(nm===''){ noNameList.push(c); }
  }
  // 중복(같은 번호 2회 이상)
  var seen={}, dupKeys={};
  for(var j=0;j<list.length;j++){
    var key=normPhone(list[j].phoneNumber);
    if(!key) continue;
    if(seen[key]){ dupKeys[key]=true; }
    seen[key]=(seen[key]||0)+1;
  }
  var added={};
  for(var k=0;k<list.length;k++){
    var kk=normPhone(list[k].phoneNumber);
    if(dupKeys[kk] && !added[kk]){
      dupList.push(list[k]); added[kk]=true;   // 대표 1개씩
    }
  }
}

/* ================= 요약 카드 렌더 ================= */
function renderSummary(){
  var wrap=document.getElementById('sumCards');
  wrap.innerHTML =
    '<div class="sum-card '+(mode==='noname'?'on':'')+'" data-mode="noname">'+
      '<div class="sum-num">'+noNameList.length+'</div>'+
      '<div class="sum-label">이름 없는 번호</div></div>'+
    '<div class="sum-card '+(mode==='dup'?'on':'')+'" data-mode="dup">'+
      '<div class="sum-num">'+dupList.length+'</div>'+
      '<div class="sum-label">중복된 번호</div></div>';
}

/* ================= 덱 렌더 ================= */
function loadDeck(){
  deckList = (mode==='noname') ? noNameList.slice() : dupList.slice();
  deckIdx = 0;
  renderCard();
}
function renderCard(){
  var deck=document.getElementById('deck');
  document.getElementById('deckLabel').textContent =
    (mode==='noname') ? '이름 없는 번호 확인' : '중복된 번호 확인';

  if(deckList.length===0){
    deck.innerHTML = '<div class="empty-note"><span class="em">✨</span>'+
      (mode==='noname'?'이름 없는 번호가 없어요.<br>깔끔하네요!':'중복된 번호가 없어요.<br>깔끔하네요!')+'</div>';
    return;
  }
  if(deckIdx >= deckList.length){
    // 이 덱 다 봄
    deck.innerHTML = '<div class="empty-note"><span class="em">👏</span>'+
      '이 목록을 모두 확인했어요.<br>다른 목록도 살펴볼까요?</div>'+
      '<button class="big-btn ghost" id="switchMode" style="margin-top:8px">'+
      (mode==='noname'?'중복된 번호 보기':'이름 없는 번호 보기')+'</button>';
    document.getElementById('switchMode').addEventListener('click', function(){
      mode = (mode==='noname')?'dup':'noname';
      renderSummary(); loadDeck();
    });
    return;
  }

  var c = deckList[deckIdx];
  var tag = (mode==='noname')
    ? '<span class="rcard-tag noname">이름 없음</span>'
    : '<span class="rcard-tag dup">중복</span>';
  var nameHtml = (c.name||'').trim()===''
    ? '<div class="rcard-name none">저장된 이름이 없어요</div>'
    : '<div class="rcard-name">'+escapeHtml(c.name)+'</div>';

  deck.innerHTML =
    '<div class="rcard">'+ tag +
      '<div class="rcard-phone">'+ escapeHtml(fmtPhone(c.phoneNumber)) +'</div>'+
      nameHtml +
      '<div class="rcard-actions">'+
        '<button class="rc-btn rc-skip" id="btnSkip">'+
          '<svg viewBox="0 0 24 24" fill="none"><path d="M9 18l6-6-6-6" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>건너뛰기</button>'+
        '<a class="rc-btn rc-call" id="btnCall" href="tel:'+ normPhone(c.phoneNumber) +'">'+
          '<svg viewBox="0 0 24 24" fill="none"><path d="M6.5 3h3l1.5 4.5-2 1.5a11 11 0 005 5l1.5-2 4.5 1.5v3a2 2 0 01-2 2A16 16 0 013 6.5 2 2 0 015 4.5" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg>전화 확인</a>'+
      '</div>'+
    '</div>'+
    '<div class="progress"><b>'+(deckIdx+1)+'</b> / '+deckList.length+'</div>';

  document.getElementById('btnSkip').addEventListener('click', nextCard);
  document.getElementById('btnCall').addEventListener('click', function(){
    // tel: 링크는 기본 동작(전화앱)으로 진행 — 막지 않음. 카운트는 nextCard에서 1회만.
    setTimeout(nextCard, 400);
  });
}

function nextCard(){
  checkedCount++;
  deckIdx++;
  if(deckIdx >= deckList.length){
    // 양쪽 다 봤으면 완료
    renderCard();
  } else {
    renderCard();
  }
}

function escapeHtml(s){
  return String(s||'').replace(/[&<>"']/g, function(m){
    return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m];
  });
}

/* ================= VCF 백업 =================
   연락처 → vCard(VCF) 문자열 생성 → 일반 공유(공유시트).
   우린 파일만 만들어 넘김. 저장/보관은 사용자(카톡 등)가. */
function buildVCF(list){
  var out=[];
  for(var i=0;i<list.length;i++){
    var c=list[i];
    var name=(c.name||'').trim() || '이름 없음';
    var tel=(c.phoneNumber||'').trim();
    if(!tel) continue;
    out.push('BEGIN:VCARD');
    out.push('VERSION:3.0');
    out.push('FN:'+vcfEsc(name));
    out.push('TEL;TYPE=CELL:'+vcfEsc(tel));
    out.push('END:VCARD');
  }
  return out.join('\r\n');
}
function vcfEsc(s){
  // vCard 특수문자 이스케이프
  return String(s||'').replace(/\\/g,'\\\\').replace(/;/g,'\\;').replace(/,/g,'\\,').replace(/\n/g,'\\n');
}

// 백업 파일 저장 — navigator.share(파일) / PC: blob 다운로드 / 최후: 텍스트 복사
async function shareVCF(){
  if(!contacts.length){ toast('먼저 연락처를 불러와 주세요'); return; }
  var vcf = buildVCF(contacts);
  var filename = 'contacts_'+vcfStamp()+'.vcf';

  // 1) navigator.share (파일) — 지원 환경(샌드박스/폰 웹)
  try{
    if(navigator.canShare){
      var file = new File([vcf], filename, { type:'text/vcard' });
      if(navigator.canShare({ files:[file] })){
        await navigator.share({ files:[file], title:'연락처 백업' });
        return;
      }
    }
  }catch(e){ if(e && e.name==='AbortError') return; }

  // 3) PC 다운로드 폴백
  try{
    var blob = new Blob([vcf], { type:'text/vcard' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url; a.download = filename; a.style.display='none';
    document.body.appendChild(a); a.click();
    setTimeout(function(){ document.body.removeChild(a); URL.revokeObjectURL(url); }, 1500);
    toast('백업 파일을 저장했어요'); return;
  }catch(e){}

  // 4) 최후: 텍스트 복사
  copyVCF(vcf);
}

// 저장이 막히는 환경용 — VCF 내용을 클립보드로
function copyVCF(vcf){
  if(!contacts.length){ toast('먼저 연락처를 불러와 주세요'); return; }
  vcf = vcf || buildVCF(contacts);
  if(navigator.clipboard && navigator.clipboard.writeText){
    navigator.clipboard.writeText(vcf).then(
      function(){ toast('백업 내용을 복사했어요 (메모·메일에 붙여넣기)'); },
      function(){ toast('길게 눌러 복사해 주세요'); }
    );
  } else { toast('복사를 지원하지 않는 환경이에요'); }
}

function b64(str){
  // UTF-8 안전 base64
  return btoa(unescape(encodeURIComponent(str)));
}
function vcfStamp(){
  var d=new Date(), p=function(n){ return (n<10?'0':'')+n; };
  return ''+d.getFullYear()+p(d.getMonth()+1)+p(d.getDate())+'_'+p(d.getHours())+p(d.getMinutes());
}

/* ================= 시작 흐름 ================= */
document.getElementById('introStart').addEventListener('click', startScan);

async function startScan(){
  show('main');
  var deck=document.getElementById('deck');
  document.getElementById('sumCards').innerHTML='';
  deck.innerHTML = '<div class="loading"><div class="spinner"></div>연락처를 살펴보는 중…</div>';
  document.getElementById('topSub').textContent='연락처를 살펴보는 중…';

  try{
    contacts = await fetchAllContacts();
  }catch(e){
    var denied = e && /permission|denied/i.test(e.message||'');
    deck.innerHTML = '<div class="empty-note"><span class="em">🔒</span>'+
      (denied
        ? '연락처 권한이 꺼져 있어요.<br>권한을 허용하면 정리를 시작할 수 있어요.'
        : '연락처를 불러오지 못했어요.<br>잠시 후 다시 시도해 주세요.')+
      '</div>'+
      '<button class="big-btn ghost" id="btnPerm" style="margin-top:8px">'+
        (denied?'연락처 권한 허용하기':'다시 시도')+'</button>';
    document.getElementById('topSub').textContent = denied?'권한이 필요해요':'다시 시도해 주세요';
    document.getElementById('btnPerm').addEventListener('click', function(){
      if(denied){ try{ fetchContacts.openPermissionDialog(); }catch(e){} }
      startScan();
    });
    return;
  }

  classify(contacts);
  document.getElementById('topSub').textContent='총 '+contacts.length+'개 중 정리 후보를 찾았어요';
  // 기본 모드: 더 많은 쪽 먼저
  mode = (noNameList.length >= dupList.length) ? 'noname' : 'dup';
  renderSummary();
  loadDeck();
  document.getElementById('tabbar').classList.add('on');   // 탭바 노출
  document.getElementById('backupCount').textContent = contacts.length || '—';

  // 요약 카드 클릭 → 모드 전환
  document.getElementById('sumCards').addEventListener('click', function(e){
    var card=e.target.closest('.sum-card');
    if(!card) return;
    mode = card.dataset.mode;
    renderSummary(); loadDeck();
  });
}

document.getElementById('doneRestart').addEventListener('click', function(){
  checkedCount=0; startScan();
});

/* ================= 탭 전환 ================= */
function switchTab(tab){
  // 화면
  var map = { main:'main', backup:'backup', restore:'restore' };
  show(map[tab] || 'main');
  document.getElementById('tabbar').classList.add('on');
  // 탭 활성화
  var tabs=document.querySelectorAll('.tab');
  for(var i=0;i<tabs.length;i++) tabs[i].classList.toggle('on', tabs[i].dataset.tab===tab);
  // 백업 화면이면 카운트 갱신
  if(tab==='backup'){
    var el=document.getElementById('backupCount');
    el.textContent = contacts.length ? contacts.length : '—';
  }
}
document.getElementById('tabbar').addEventListener('click', function(e){
  var t=e.target.closest('.tab'); if(!t) return;
  switchTab(t.dataset.tab);
});
document.getElementById('btnBackup').addEventListener('click', shareVCF);
document.getElementById('btnBackupCopy').addEventListener('click', function(){ copyVCF(); });

/* 핀치줌 차단 */
document.addEventListener('gesturestart', function(e){ e.preventDefault(); });
document.addEventListener('touchmove', function(e){
  if(e.scale && e.scale!==1){ e.preventDefault(); }
}, { passive:false });
